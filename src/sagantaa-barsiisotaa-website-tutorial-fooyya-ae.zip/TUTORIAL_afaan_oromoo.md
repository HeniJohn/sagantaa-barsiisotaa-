> **Yaadachiisa:** Tutorial kun amma website mataa isaa keessattis ni argama —
> Menu (⋮) jala **"Tutorial (Akkaataa Fayyadamaa)"** jedhu tuqi. Achittis
> tarkaanfiiwwan (icon waliin) fi iddoo viidiyoo YouTube itti maxxansan (Admin
> qofaan) ni argama.

# Akkaataa Website "Sagantaa Barsiisota" Itti Fayyadamaa — Tutorial Guutuu

Kun fakkeenya (demo) mana barsumaa tokko fayyadamee, jalqabaa hanga sagantaan
guutuun uumamutti tarkaanfii tarkaanfiidhaan kan si agarsiisu dha. Maqaalee fi
lakkoofsi armaan gadii fakkeenyuma — kan mana barsumaa keetiif ta'u ofii kee
galchuu dandeessa.

---

## Tarkaanfii 1 — Seensa (Login)

Fuula jalqabaa irratti gahee kee (Bulchaa / Admin ykn Barsiisaa / Teacher)
filadhuutii maqaa fayyadamaa fi iyyuu (password) galchi.

- **Bulchaa (Admin):** kan Barsiisota, Kutaalee, Barnoota, Ramaddii fi
  Sagantaa uumu/gulaalu danda'u.
- **Barsiisaa (Teacher):** kan sagantaa ofii isaa qofa ilaalu danda'u,
  waan tokko illee hin gulaalu.

Iyyuu jalqabaa (default) kan `.env` keessatti hin jijjiirmin:
`admin / admin123` fi `teacher / teacher123`. **Kana dursitee jijjiiruu
qabda** — gara gadiitti "Hanqinoota Argaman" jalatti ni ibsama.

---

## Tarkaanfii 2 — Barsiisota Galchi

"Barsiisota" jedhu jala deemi, maqaa barsiisaa tokko tokkoon galchi:

- Barsiisaa Kadir
- Barsiisaa Salamaa
- Barsiisittii Caaltuu

---

## Tarkaanfii 3 — Kutaalee Galchi

"Kutaalee" jala:

- Kutaa 9A
- Kutaa 9B

---

## Tarkaanfii 4 — Barnoota Galchi

"Barnoota" jala:

- Herrega
- Afaan Ingiliffaa
- Fiiziksii
- Afaan Oromoo

---

## Tarkaanfii 5 — Ramaddii Uumi (Barsiisaa + Barnoota + Kutaa + Sa'aatii/torban)

"Ramaddii" jala, walitti fidiinsa armaan gadii galchi (fakkeenya):

| Barsiisaa           | Barnoota           | Kutaa    | Sa'aatii/torban |
|----------------------|--------------------|----------|------------------|
| Barsiisaa Kadir      | Herrega            | 9A       | 5                |
| Barsiisaa Kadir      | Herrega            | 9B       | 5                |
| Barsiisaa Salamaa    | Afaan Ingiliffaa   | 9A       | 4                |
| Barsiisaa Salamaa    | Fiiziksii          | 9B       | 4                |
| Barsiisittii Caaltuu | Afaan Oromoo       | 9A       | 3                |
| Barsiisittii Caaltuu | Fiiziksii          | 9A       | 3                |
| Barsiisaa Salamaa    | Afaan Ingiliffaa   | 9B       | 4                |

Tokkoon tokkoon walitti fidiinsaa erga galchitee booda "Dabali" tuqi.

---

## Tarkaanfii 6 — Sagantaa Uumi (Generate Schedule)

"Sagantaa" jala deemi, "Sa'aatii guyyaa tokkotti" (Periods per day) = **6**
godhi, ergasii **"Sagantaa Uumi"** tuqi.

Sagantichi sekondii muraasa keessatti ni uumama. Mata dureen "Kutaan ilaali /
Barsiisaa ilaali" jedhu gubbaadhaan jira — kanaan sagantaa kutaa tokkoo ykn
barsiisaa tokkoo cinaa cinaan ilaaluu dandeessa.

### Bu'aa dhugaa (fooyya'e booda) — Sagantaa Kutaa 9A:

| Sa'aatii | Wiixata | Kibxata | Roobii | Kamiisa | Jimaata |
|----------|---------|---------|--------|---------|---------|
| 1        | Herrega | Herrega | Herrega| Afaan Oromoo | Herrega |
| 2        | Afaan Ing. | Afaan Ing. | Afaan Ing. | Herrega | -- |
| 3        | Afaan Ing. | -- | -- | -- | -- |
| 4        | -- | Afaan Oromoo | -- | -- | Afaan Oromoo |
| 5        | -- | Fiiziksii | Fiiziksii | -- | -- |
| 6        | Fiiziksii | -- | -- | -- | -- |

Akkuma argitu: barnoota tokko sa'aatii lama walitti aansee (back-to-back)
kutaa 9A tti hin argamu — bu'aan kun sirna haaraa fooyya'aa dha (gara gadiitti
"Fooyya'ii Guddaa" jalatti ibsama).

---

## Tarkaanfii 7 — Sagantaa Olkaa'i (Save/Export)

Menu (☰ ykn bal bal xiqqoo) irraa **"Sagantaa Olkaa'i"** filadhu:

- **PDF** — sagantaa akka waraqaatti maxxansuuf.
- **Suura (PNG)** — sagantaa akka suuraatti WhatsApp ykn Telegram irratti
  qooduuf.

---

## Tarkaanfii 8 — Barsiisaan Sagantaa Ofii Isaa Akkamitti Ilaala

Barsiisaan gahee "Barsiisaa" filatee seenee, maqaa isaa filachuudhaan qofa
sagantaa isaa (bakka barbaachisu hunda irraa walitti qabame) ni arga —
gulaaluu hin danda'u.

---

## Hanqinoota Argaman + Fooyya'iinsa Godhame

### 1. **Fooyya'ii Guddaa — Sagantaan Barsiisaa/Kutaa Walitti Aanee Uumamaa Ture**
Dur, sirni sagantaa uumu sa'aatii duraan bilisa ta'e argame qofa guutee ture —
kanaafuu barsiisaan tokko sa'aatii 1 fi 2 walitti aansee, ykn kutaan tokko
barnoota tokko sa'aatii lama walitti aansee argachuu danda'a ture. **Kana
sirreesseera**: amma sirnichi sa'aatii bilisa hunda ilaalee, kan barsiisaa
ykn barnoota walitti hin ansine (yookaan xiqqaate sa'aatii tokko gidduu
hin qabne) dursee filata. Yoo filannoon hin jirre qofa (haala dhumaa),
sa'aatii walitti aanu ni fayyadama — kanaan sagantaan hin bilcheessamne
(unplaced) tokko illee akka hin uumamne. Hojiin kun `App.jsx` keessatti
`generateSchedule()` jedhamu keessatti fooyya'eera.

### 2. **Iyyuun (Password) Bulchaa Kodii Keessatti Ifatti Mul'ata**
Iyyuun ammayyaa (`admin123` fi kkf) kodii "bundle" JavaScript keessatti dhoksaa
osoo hin taane ifatti mul'ata — namni kamiyyuu "View Source" godhee argachuu
danda'a. Kun rakkina nageenyaa guddaadha. **Furmaata:**
- `.env` keessatti iyyuu haaraa fi jabaa kaa'i (`VITE_ADMIN_PASSWORD=...`).
- Yeroo dhihootti (long-term), sirna seensaa kana gara **Firebase
  Authentication**tti geeddaruun filannoo gaarii dha — kun garuu jijjiirama
  xiqqoo hin taane waan ta'eef, yoo barbaachise gargaarsa kiyya
  fayyadamuu dandeessa.

### 3. **Firestore "Test Mode" Keessa Jira**
Kuusaan (database) ammaan tana "test mode" irratti hundaa'e jira —
kunis guyyaa 30 booda ofumaan cufama, akkasumas hamma yeroo sanaatti namni
kamiyyuu (link/config argatee) daataa dubbisuu fi jijjiiruu danda'a. Sirna
kuusaa "Security Rules" jedhamu Firebase Console irratti dabaluu
qabda — fakkeenyaaf, dubbisuu bilisa (public read) garuu barreessuu
(write) qofa gahee Admin'iif dhiisuu.

### 4. **Doc Tokkicha Hunda Waliin Qooda (Concurrency)**
Daataan hundi (barsiisota, kutaalee, ramaddii, sagantaa) galmee (document)
Firestore tokkicha keessatti walitti qabamanii jiru. Yoo Admin lama yeroo
tokkotti garaa garaan jijjiiraman, kan boodarra galfame kan duraa haqa
("last write wins"). Mana barsumaa xiqqaaf rakkoo guddaa miti, garuu Admin
tokko qofa yeroo tokkotti akka gulaalu gorsa.

### 5. **Deebi'anii Ilaaluu Yoo Barbaachise**
- Yoo kutaa/barsiisaa haaraa dabaltee ykn hire, sagantaan durii ni haqama
  (`schedule: null`) — kun kan barbaadamu dha (sagantaan moofaan akka hin
  dogoggorre), garuu Admin'ni beekuu qaba akka deebi'ee "Sagantaa Uumi"
  tuqu qabu.
- Sa'aatii/torban walumaa galatti (assignments hunda) yoo sa'aatii guyyaa
  shanan (periodsPerDay × 5) caalu, sagantaan guutummaatti hin uumamu —
  ergaan "conflict warning" jedhu ni mul'ata, sa'aatii guyyaa dabaluu ykn
  sa'aatii ramaddii xiqqeessuu si gaafata.

---

## Gabaabinaan

Fayidaan kee (login, galmee, ramaddii, generate, export) sirriitti
qophaa'eera — namni haaraa kamiyyuu salphaatti fayyadamuu danda'a. Rakkoon
inni guddaan ture sagantaan barsiisaa/kutaa walitti aanee uumamuu ture — kun
amma furameera. Waan hafe (iyyuu fi Firestore rules) nageenyaaf yeroon
xiqqoon si barbaachisa, garuu sirna hojii isaa hin jijjiiru.
